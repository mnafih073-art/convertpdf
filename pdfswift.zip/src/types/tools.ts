export type ToolCategory = 'to-pdf' | 'from-pdf' | 'organize';

export type ToolId =
  | 'images-to-pdf'
  | 'merge-pdf'
  | 'split-pdf'
  | 'remove-pages'
  | 'extract-pages'
  | 'pdf-to-images'
  | 'pdf-to-word'
  | 'word-to-pdf'
  | 'excel-to-pdf'
  | 'pdf-to-excel'
  | 'pptx-to-pdf'
  | 'pdf-to-pptx';

export interface ToolDefinition {
  id: ToolId;
  name: string;
  shortLabel: string;
  description: string;
  category: ToolCategory;
  accept: string;
  acceptLabel: string;
  multiple: boolean;
  outputLabel: string;
}

export interface UploadedFileItem {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  pageCount?: number;
  previewUrl?: string;
}

export interface PdfPageThumbnail {
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
}

export interface GeneratedOutputFile {
  name: string;
  blob: Blob;
  size: number;
  previewUrl?: string;
}

export interface ConversionResult {
  primaryFile: GeneratedOutputFile;
  extraFiles?: GeneratedOutputFile[];
  zipFile?: GeneratedOutputFile;
  summary: string;
  previewTable?: string[][];
}

export interface ImageToPdfOptions {
  pageSize: 'fit' | 'a4' | 'letter';
  orientation: 'auto' | 'portrait' | 'landscape';
  margin: 'none' | 'compact' | 'standard';
}

export interface SplitPdfOptions {
  mode: 'every-page' | 'interval' | 'ranges';
  interval: number;
  ranges: string;
}

export interface PdfToImageOptions {
  format: 'jpg' | 'png' | 'webp';
  dpi: 150 | 220 | 300;
  ranges: string;
}

export interface ExcelToPdfOptions {
  orientation: 'landscape' | 'portrait';
  includeGridlines: boolean;
}
