export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const exponent = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, exponent);
  return `${value >= 10 || exponent === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[exponent]}`;
}

export function stripExtension(filename: string): string {
  const lastDot = filename.lastIndexOf('.');
  return lastDot > 0 ? filename.slice(0, lastDot) : filename;
}

export function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

/**
 * Parses human page range strings like "1-3, 5, 8-10" into sorted unique 1-based page numbers.
 */
export function parsePageRanges(input: string, maxPages: number): number[] {
  const trimmed = input.trim();
  if (!trimmed) return [];

  const result = new Set<number>();
  const tokens = trimmed.split(',').map((t) => t.trim()).filter(Boolean);

  for (const token of tokens) {
    if (token.includes('-')) {
      const parts = token.split('-').map((p) => Number.parseInt(p.trim(), 10));
      if (parts.length === 2 && !Number.isNaN(parts[0]) && !Number.isNaN(parts[1])) {
        const start = Math.max(1, Math.min(parts[0], parts[1]));
        const end = Math.min(maxPages, Math.max(parts[0], parts[1]));
        for (let p = start; p <= end; p++) {
          result.add(p);
        }
      }
    } else {
      const page = Number.parseInt(token, 10);
      if (!Number.isNaN(page) && page >= 1 && page <= maxPages) {
        result.add(page);
      }
    }
  }

  return Array.from(result).sort((a, b) => a - b);
}

/**
 * Parses split range groups like "1-3, 4-7, 8-10" into separate page arrays.
 */
export function parseSplitGroups(input: string, maxPages: number): number[][] {
  const tokens = input
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);

  const groups: number[][] = [];
  for (const token of tokens) {
    const pages = parsePageRanges(token, maxPages);
    if (pages.length > 0) {
      groups.push(pages);
    }
  }
  return groups;
}

export function formatPageSelectionSummary(pages: number[]): string {
  if (pages.length === 0) return '';
  const sorted = [...pages].sort((a, b) => a - b);
  const ranges: string[] = [];
  let start = sorted[0];
  let prev = sorted[0];

  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i] === prev + 1) {
      prev = sorted[i];
    } else {
      ranges.push(start === prev ? `${start}` : `${start}-${prev}`);
      start = sorted[i];
      prev = sorted[i];
    }
  }
  ranges.push(start === prev ? `${start}` : `${start}-${prev}`);
  return ranges.join(', ');
}
