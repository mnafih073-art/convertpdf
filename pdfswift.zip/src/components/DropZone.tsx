import { Upload } from 'lucide-react';
import { motion } from 'motion/react';
import { useRef, useState } from 'react';
import type { ToolDefinition } from '../types/tools';

interface DropZoneProps {
  tool: ToolDefinition;
  compact?: boolean;
  onFilesAdded: (files: File[]) => void;
  inputRef?: React.RefObject<HTMLInputElement | null>;
}

export function DropZone({ tool, compact = false, onFilesAdded, inputRef }: DropZoneProps) {
  const internalRef = useRef<HTMLInputElement | null>(null);
  const resolvedRef = inputRef ?? internalRef;
  const [isDragging, setIsDragging] = useState(false);

  const handleFiles = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const filesArray = Array.from(fileList);
    onFilesAdded(tool.multiple ? filesArray : [filesArray[0]]);
    if (resolvedRef.current) {
      resolvedRef.current.value = '';
    }
  };

  return (
    <motion.div
      onDragOver={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isDragging) setIsDragging(true);
      }}
      onDragLeave={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        handleFiles(e.dataTransfer.files);
      }}
      animate={{
        scale: isDragging ? 1.008 : 1,
      }}
      transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
      className={`relative flex flex-col items-center justify-center rounded-xl border border-dashed text-center transition-colors duration-150 ${
        compact ? 'px-6 py-7' : 'px-6 py-14 sm:py-16'
      } ${
        isDragging
          ? 'border-rose-500 bg-rose-50/60'
          : 'border-zinc-300 bg-[#FAFAFA] hover:border-zinc-400 hover:bg-zinc-50'
      }`}
    >
      <input
        ref={resolvedRef}
        type="file"
        accept={tool.accept}
        multiple={tool.multiple}
        onChange={(e) => handleFiles(e.target.files)}
        className="sr-only"
        aria-label={`Upload files for ${tool.name}`}
      />

      <motion.div
        animate={{ y: isDragging ? -3 : 0 }}
        transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        className={`mb-4 flex h-12 w-12 items-center justify-center rounded-xl border transition-colors ${
          isDragging
            ? 'border-rose-200 bg-white text-rose-600'
            : 'border-zinc-200 bg-white text-zinc-700'
        }`}
      >
        <Upload className="h-5 w-5" aria-hidden="true" />
      </motion.div>

      <h3 className="font-display text-base font-semibold text-zinc-900">
        {isDragging
          ? 'Drop files to load'
          : tool.multiple
          ? 'Drop your files here, or browse'
          : 'Drop your file here, or browse'}
      </h3>

      <p className="mt-1.5 text-sm text-zinc-500">
        <span>Accepts {tool.acceptLabel}</span>
        <span aria-hidden="true" className="mx-1.5 text-zinc-300">
          ·
        </span>
        <span>Output {tool.outputLabel}</span>
      </p>

      <button
        type="button"
        onClick={() => resolvedRef.current?.click()}
        className="mt-5 rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-zinc-800 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600"
      >
        {tool.multiple ? 'Select Files' : 'Select File'}
      </button>
    </motion.div>
  );
}
