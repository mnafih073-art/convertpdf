import { CheckCircle2, Download, RotateCcw } from 'lucide-react';
import { motion } from 'motion/react';
import type { ConversionResult } from '../types/tools';
import { formatBytes, triggerDownload } from '../utils/formatters';

interface ResultPanelProps {
  result: ConversionResult;
  onReset: () => void;
}

export function ResultPanel({ result, onReset }: ResultPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-5"
    >
      {/* Primary Download Banner */}
      <div className="flex flex-col gap-4 rounded-xl border border-emerald-200 bg-emerald-50/40 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <CheckCircle2
            className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600"
            aria-hidden="true"
          />
          <div>
            <h3 className="font-display text-base font-semibold text-zinc-950">
              Ready to download
            </h3>
            <p className="mt-0.5 text-sm text-zinc-600">{result.summary}</p>
            <p className="mt-1.5 text-xs font-mono text-zinc-500 tabular-nums">
              {result.primaryFile.name}
              <span aria-hidden="true" className="mx-1.5 text-zinc-300">
                ·
              </span>
              {formatBytes(result.primaryFile.size)}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => triggerDownload(result.primaryFile.blob, result.primaryFile.name)}
            className="inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-zinc-800 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600"
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            <span>{result.zipFile ? 'Download All (ZIP)' : 'Download File'}</span>
          </button>

          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3.5 py-2.5 text-sm font-medium text-zinc-700 transition-colors hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Start Over</span>
          </button>
        </div>
      </div>

      {/* Extracted Table Preview (PDF to Excel) */}
      {result.previewTable && result.previewTable.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-medium text-zinc-500">
            Extracted preview (first {result.previewTable.length} rows of Sheet 1)
          </p>
          <div className="overflow-x-auto rounded-xl border border-zinc-200 bg-white">
            <table className="w-full border-collapse text-left text-xs">
              <tbody>
                {result.previewTable.map((row, rIdx) => (
                  <tr
                    key={rIdx}
                    className={
                      rIdx === 0
                        ? 'border-b border-zinc-200 bg-zinc-50 font-semibold text-zinc-900'
                        : 'border-b border-zinc-100 last:border-b-0 text-zinc-700'
                    }
                  >
                    {row.map((cell, cIdx) => (
                      <td
                        key={cIdx}
                        className="max-w-[220px] truncate px-3 py-2 font-mono tabular-nums"
                      >
                        {cell || '—'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Multi-file Output Grid (Split PDF / PDF to Images / Extract Separate) */}
      {result.extraFiles && result.extraFiles.length > 1 && (
        <div className="space-y-2.5">
          <p className="text-xs font-medium text-zinc-500">
            Individual files ({result.extraFiles.length})
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
            {result.extraFiles.map((item) => (
              <div
                key={item.name}
                className="flex items-center justify-between gap-3 rounded-lg border border-zinc-200 bg-white p-3"
              >
                <div className="flex min-w-0 items-center gap-2.5">
                  {item.previewUrl && (
                    <img
                      src={item.previewUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="h-11 w-9 shrink-0 rounded border border-zinc-200 object-cover"
                    />
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-xs font-medium text-zinc-900">{item.name}</p>
                    <p className="text-[11px] font-mono text-zinc-500 tabular-nums">
                      {formatBytes(item.size)}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => triggerDownload(item.blob, item.name)}
                  aria-label={`Download ${item.name}`}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-700 transition-colors hover:border-zinc-900 hover:bg-zinc-900 hover:text-white cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
