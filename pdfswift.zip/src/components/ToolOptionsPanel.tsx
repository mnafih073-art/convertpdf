import type {
  ExcelToPdfOptions,
  ImageToPdfOptions,
  PdfToImageOptions,
  SplitPdfOptions,
  ToolId,
} from '../types/tools';

interface ToolOptionsPanelProps {
  toolId: ToolId;
  totalPages: number;
  imageOptions: ImageToPdfOptions;
  onChangeImageOptions: (opts: ImageToPdfOptions) => void;
  splitOptions: SplitPdfOptions;
  onChangeSplitOptions: (opts: SplitPdfOptions) => void;
  extractSeparate: boolean;
  onChangeExtractSeparate: (val: boolean) => void;
  pdfToImageOptions: PdfToImageOptions;
  onChangePdfToImageOptions: (opts: PdfToImageOptions) => void;
  excelOptions: ExcelToPdfOptions;
  onChangeExcelOptions: (opts: ExcelToPdfOptions) => void;
}

export function ToolOptionsPanel({
  toolId,
  totalPages,
  imageOptions,
  onChangeImageOptions,
  splitOptions,
  onChangeSplitOptions,
  extractSeparate,
  onChangeExtractSeparate,
  pdfToImageOptions,
  onChangePdfToImageOptions,
  excelOptions,
  onChangeExcelOptions,
}: ToolOptionsPanelProps) {
  if (toolId === 'images-to-pdf') {
    return (
      <div className="grid grid-cols-1 gap-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4 sm:grid-cols-3">
        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Page Size</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {(['fit', 'a4', 'letter'] as const).map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => onChangeImageOptions({ ...imageOptions, pageSize: size })}
                className={`flex-1 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  imageOptions.pageSize === size
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {size === 'fit' ? 'Fit Image' : size.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Orientation</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {(['auto', 'portrait', 'landscape'] as const).map((orient) => (
              <button
                key={orient}
                type="button"
                disabled={imageOptions.pageSize === 'fit'}
                onClick={() => onChangeImageOptions({ ...imageOptions, orientation: orient })}
                className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium capitalize transition-colors whitespace-nowrap cursor-pointer disabled:opacity-40 ${
                  imageOptions.orientation === orient
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {orient}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Margin</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {(['none', 'compact', 'standard'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => onChangeImageOptions({ ...imageOptions, margin: m })}
                className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium capitalize transition-colors whitespace-nowrap cursor-pointer ${
                  imageOptions.margin === m
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (toolId === 'split-pdf') {
    return (
      <div className="space-y-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4">
        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Split Mode</span>
          <div className="inline-flex rounded-lg bg-zinc-200/70 p-0.5">
            {[
              { id: 'every-page', label: 'Every Page' },
              { id: 'interval', label: 'Fixed Interval' },
              { id: 'ranges', label: 'Custom Ranges' },
            ].map((mode) => (
              <button
                key={mode.id}
                type="button"
                onClick={() =>
                  onChangeSplitOptions({
                    ...splitOptions,
                    mode: mode.id as SplitPdfOptions['mode'],
                  })
                }
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  splitOptions.mode === mode.id
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {mode.label}
              </button>
            ))}
          </div>
        </div>

        {splitOptions.mode === 'interval' && (
          <div className="flex items-center gap-3">
            <label htmlFor="split-interval" className="text-xs font-medium text-zinc-700">
              Pages per split PDF:
            </label>
            <input
              id="split-interval"
              type="number"
              min={1}
              max={Math.max(1, totalPages)}
              value={splitOptions.interval}
              onChange={(e) =>
                onChangeSplitOptions({
                  ...splitOptions,
                  interval: Math.max(1, Number.parseInt(e.target.value, 10) || 1),
                })
              }
              className="w-20 rounded-md border border-zinc-200 bg-white px-2.5 py-1.5 text-sm font-mono tabular-nums text-zinc-900 focus:border-zinc-900 focus:outline-none"
            />
          </div>
        )}

        {splitOptions.mode === 'ranges' && (
          <div>
            <label htmlFor="split-ranges" className="block text-xs font-medium text-zinc-700 mb-1.5">
              Enter comma-separated page ranges (each range outputs one PDF):
            </label>
            <input
              id="split-ranges"
              type="text"
              value={splitOptions.ranges}
              onChange={(e) =>
                onChangeSplitOptions({ ...splitOptions, ranges: e.target.value })
              }
              placeholder={`e.g. 1-2, 3-${Math.max(4, totalPages)}`}
              className="w-full max-w-md rounded-md border border-zinc-200 bg-white px-3 py-2 text-sm font-mono text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none"
            />
          </div>
        )}
      </div>
    );
  }

  if (toolId === 'extract-pages') {
    return (
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4">
        <div>
          <span className="text-xs font-medium text-zinc-700">Extraction Output</span>
          <p className="text-xs text-zinc-500 mt-0.5">
            Combine extracted pages into one PDF or save each page separately.
          </p>
        </div>
        <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
          <button
            type="button"
            onClick={() => onChangeExtractSeparate(false)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
              !extractSeparate
                ? 'bg-white text-zinc-950 shadow-xs'
                : 'text-zinc-600 hover:text-zinc-950'
            }`}
          >
            Single PDF
          </button>
          <button
            type="button"
            onClick={() => onChangeExtractSeparate(true)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
              extractSeparate
                ? 'bg-white text-zinc-950 shadow-xs'
                : 'text-zinc-600 hover:text-zinc-950'
            }`}
          >
            Separate PDFs (ZIP)
          </button>
        </div>
      </div>
    );
  }

  if (toolId === 'pdf-to-images') {
    return (
      <div className="grid grid-cols-1 gap-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4 sm:grid-cols-3">
        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Image Format</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {(['jpg', 'png', 'webp'] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => onChangePdfToImageOptions({ ...pdfToImageOptions, format: fmt })}
                className={`flex-1 rounded-md px-2.5 py-1.5 text-xs font-medium uppercase transition-colors whitespace-nowrap cursor-pointer ${
                  pdfToImageOptions.format === fmt
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Resolution</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {([150, 220, 300] as const).map((dpi) => (
              <button
                key={dpi}
                type="button"
                onClick={() => onChangePdfToImageOptions({ ...pdfToImageOptions, dpi })}
                className={`flex-1 rounded-md px-2 py-1.5 text-xs font-mono font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  pdfToImageOptions.dpi === dpi
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {dpi} DPI
              </button>
            ))}
          </div>
        </div>

        <div>
          <label
            htmlFor="pdf-img-ranges"
            className="block text-xs font-medium text-zinc-500 mb-2"
          >
            Pages (blank = all)
          </label>
          <input
            id="pdf-img-ranges"
            type="text"
            value={pdfToImageOptions.ranges}
            onChange={(e) =>
              onChangePdfToImageOptions({ ...pdfToImageOptions, ranges: e.target.value })
            }
            placeholder={totalPages > 0 ? `1-${totalPages}` : 'e.g. 1-3, 5'}
            className="w-full rounded-md border border-zinc-200 bg-white px-2.5 py-1.5 text-xs font-mono text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none"
          />
        </div>
      </div>
    );
  }

  if (toolId === 'excel-to-pdf') {
    return (
      <div className="grid grid-cols-1 gap-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4 sm:grid-cols-2">
        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Page Orientation</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {(['landscape', 'portrait'] as const).map((orient) => (
              <button
                key={orient}
                type="button"
                onClick={() => onChangeExcelOptions({ ...excelOptions, orientation: orient })}
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors whitespace-nowrap cursor-pointer ${
                  excelOptions.orientation === orient
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {orient}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="block text-xs font-medium text-zinc-500 mb-2">Table Style</span>
          <div className="flex rounded-lg bg-zinc-200/70 p-0.5">
            {[
              { val: true, label: 'Gridlines' },
              { val: false, label: 'Clean Rows' },
            ].map((opt) => (
              <button
                key={String(opt.val)}
                type="button"
                onClick={() =>
                  onChangeExcelOptions({ ...excelOptions, includeGridlines: opt.val })
                }
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  excelOptions.includeGridlines === opt.val
                    ? 'bg-white text-zinc-950 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
