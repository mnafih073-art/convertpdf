import { ArrowDown, ArrowUp, FileText, Plus, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { UploadedFileItem } from '../types/tools';
import { formatBytes } from '../utils/formatters';

interface FileQueueListProps {
  files: UploadedFileItem[];
  allowReorder: boolean;
  allowMultiple: boolean;
  onMove: (index: number, direction: -1 | 1) => void;
  onRemove: (id: string) => void;
  onAddMore: () => void;
}

export function FileQueueList({
  files,
  allowReorder,
  allowMultiple,
  onMove,
  onRemove,
  onAddMore,
}: FileQueueListProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
          <span className="tabular-nums">
            {files.length} {files.length === 1 ? 'file' : 'files'} queued
          </span>
          <span aria-hidden="true" className="text-zinc-300">
            ·
          </span>
          <span className="font-mono tabular-nums">
            {formatBytes(files.reduce((acc, f) => acc + f.size, 0))}
          </span>
        </div>

        {allowMultiple && (
          <button
            type="button"
            onClick={onAddMore}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Add More</span>
          </button>
        )}
      </div>

      <div className="divide-y divide-zinc-200 rounded-xl border border-zinc-200 bg-white overflow-hidden">
        <AnimatePresence initial={false}>
          {files.map((item, idx) => {
            const ext = item.name.split('.').pop()?.toUpperCase() || 'FILE';
            return (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                className="flex items-center justify-between gap-4 px-4 py-3 transition-colors hover:bg-zinc-50/70"
              >
                <div className="flex min-w-0 items-center gap-3">
                  {item.previewUrl ? (
                    <img
                      src={item.previewUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="h-10 w-10 shrink-0 rounded-md border border-zinc-200 bg-zinc-50 object-cover"
                    />
                  ) : (
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-zinc-200 bg-zinc-50 text-zinc-500">
                      <FileText className="h-4 w-4" aria-hidden="true" />
                    </div>
                  )}

                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-zinc-900">{item.name}</p>
                    <p className="mt-0.5 flex items-center gap-1.5 text-xs text-zinc-500 font-mono tabular-nums">
                      <span>{ext}</span>
                      <span aria-hidden="true" className="text-zinc-300">
                        ·
                      </span>
                      <span>{formatBytes(item.size)}</span>
                      {typeof item.pageCount === 'number' && (
                        <>
                          <span aria-hidden="true" className="text-zinc-300">
                            ·
                          </span>
                          <span>
                            {item.pageCount} {item.pageCount === 1 ? 'page' : 'pages'}
                          </span>
                        </>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {allowReorder && files.length > 1 && (
                    <>
                      <button
                        type="button"
                        onClick={() => onMove(idx, -1)}
                        disabled={idx === 0}
                        aria-label={`Move ${item.name} up`}
                        className="flex h-8 w-8 items-center justify-center rounded-md text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                      >
                        <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onMove(idx, 1)}
                        disabled={idx === files.length - 1}
                        aria-label={`Move ${item.name} down`}
                        className="flex h-8 w-8 items-center justify-center rounded-md text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                      >
                        <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => onRemove(item.id)}
                    aria-label={`Remove ${item.name}`}
                    className="flex h-8 w-8 items-center justify-center rounded-md text-zinc-400 transition-colors hover:bg-rose-50 hover:text-rose-600 cursor-pointer"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
