import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { TOOL_CATEGORIES, TOOLS_CATALOG } from '../data/toolsCatalog';
import type { ToolId } from '../types/tools';
import { getToolIcon } from './ToolSidebar';

interface ToolsDirectoryProps {
  activeToolId: ToolId;
  onSelectTool: (id: ToolId) => void;
}

export function ToolsDirectory({ activeToolId, onSelectTool }: ToolsDirectoryProps) {
  return (
    <section
      id="tools-directory"
      aria-labelledby="directory-heading"
      className="mx-auto max-w-[1360px] px-6 py-16 border-t border-zinc-200"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between mb-10">
        <div>
          <h2
            id="directory-heading"
            className="font-display text-2xl font-bold tracking-tight text-zinc-950 text-balance"
          >
            All document tools
          </h2>
          <p className="mt-1.5 text-sm text-zinc-600 max-w-xl">
            Every converter and PDF organizer runs directly in your browser without file limits,
            accounts, or watermarks.
          </p>
        </div>
        <p className="text-xs font-mono text-zinc-500 tabular-nums">
          12 tools · No sign-up required
        </p>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        {TOOL_CATEGORIES.map((category, catIndex) => {
          const categoryTools = TOOLS_CATALOG.filter((t) => t.category === category.id);
          return (
            <div key={category.id} className="space-y-4">
              <div className="border-b border-zinc-200 pb-3">
                <p className="text-xs font-mono text-zinc-400 tabular-nums">
                  0{catIndex + 1}
                </p>
                <h3 className="mt-1 font-display text-base font-semibold text-zinc-950">
                  {category.label}
                </h3>
                <p className="mt-0.5 text-xs text-zinc-500">{category.description}</p>
              </div>

              <div className="divide-y divide-zinc-100">
                {categoryTools.map((tool) => {
                  const Icon = getToolIcon(tool.id);
                  const isActive = tool.id === activeToolId;
                  return (
                    <motion.button
                      key={tool.id}
                      type="button"
                      whileHover={{ x: 2 }}
                      transition={{ duration: 0.14, ease: [0.16, 1, 0.3, 1] }}
                      onClick={() => {
                        onSelectTool(tool.id);
                        document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="group flex w-full items-start justify-between gap-3 py-3.5 text-left transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <Icon
                          className={`mt-0.5 h-4 w-4 shrink-0 transition-colors ${
                            isActive
                              ? 'text-rose-600'
                              : 'text-zinc-400 group-hover:text-zinc-900'
                          }`}
                          aria-hidden="true"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-sm font-medium transition-colors ${
                                isActive
                                  ? 'text-rose-600'
                                  : 'text-zinc-900 group-hover:text-zinc-950'
                              }`}
                            >
                              {tool.name}
                            </span>
                            <span className="text-xs font-mono text-zinc-400">
                              {tool.acceptLabel.split(',')[0]} → {tool.outputLabel}
                            </span>
                          </div>
                          <p className="mt-0.5 text-xs text-zinc-500 line-clamp-2">
                            {tool.description}
                          </p>
                        </div>
                      </div>
                      <ArrowUpRight
                        className="mt-0.5 h-4 w-4 shrink-0 text-zinc-300 transition-colors group-hover:text-zinc-900"
                        aria-hidden="true"
                      />
                    </motion.button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
