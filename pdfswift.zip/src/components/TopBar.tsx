import type { ToolCategory } from '../types/tools';

interface TopBarProps {
  onSelectCategory: (category: ToolCategory | 'all') => void;
  onQuickOpenFile: () => void;
}

export function TopBar({ onSelectCategory, onQuickOpenFile }: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-zinc-200/80 bg-[#FAFAFA]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1360px] items-center justify-between gap-8 px-6 py-3.5">
        {/* Zone 1: Single-line Wordmark */}
        <a
          href="#workspace"
          onClick={(e) => {
            e.preventDefault();
            onSelectCategory('all');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="font-display text-lg font-bold tracking-tight text-zinc-900 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-rose-600"
        >
          PDF<span className="text-rose-600">Swift</span>
        </a>

        {/* Zone 2: 4 single-line navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-600"
        >
          <a
            href="#tools-directory"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategory('all');
              document.getElementById('tools-directory')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-950 transition-colors whitespace-nowrap shrink-0 underline-offset-4 hover:underline"
          >
            All Tools
          </a>
          <a
            href="#workspace"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategory('to-pdf');
              document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-950 transition-colors whitespace-nowrap shrink-0 underline-offset-4 hover:underline"
          >
            Convert to PDF
          </a>
          <a
            href="#workspace"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategory('from-pdf');
              document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-950 transition-colors whitespace-nowrap shrink-0 underline-offset-4 hover:underline"
          >
            From PDF
          </a>
          <a
            href="#workspace"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategory('organize');
              document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-950 transition-colors whitespace-nowrap shrink-0 underline-offset-4 hover:underline"
          >
            Organize
          </a>
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onQuickOpenFile}
            className="rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-zinc-800 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600"
          >
            Open Files
          </button>
        </div>
      </div>
    </header>
  );
}
