import { Check, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import type { PdfPageThumbnail } from '../types/tools';
import { formatPageSelectionSummary, parsePageRanges } from '../utils/formatters';

interface PageThumbnailGridProps {
  mode: 'remove' | 'extract';
  totalPages: number;
  thumbnails: PdfPageThumbnail[];
  isRendering: boolean;
  selectedPages: number[];
  onChangeSelected: (pages: number[]) => void;
}

export function PageThumbnailGrid({
  mode,
  totalPages,
  thumbnails,
  isRendering,
  selectedPages,
  onChangeSelected,
}: PageThumbnailGridProps) {
  const selectedSet = new Set(selectedPages);

  const togglePage = (pageNum: number) => {
    if (selectedSet.has(pageNum)) {
      onChangeSelected(selectedPages.filter((p) => p !== pageNum));
    } else {
      onChangeSelected([...selectedPages, pageNum].sort((a, b) => a - b));
    }
  };

  const selectOdd = () => {
    const pages: number[] = [];
    for (let i = 1; i <= totalPages; i += 2) pages.push(i);
    onChangeSelected(pages);
  };

  const selectEven = () => {
    const pages: number[] = [];
    for (let i = 2; i <= totalPages; i += 2) pages.push(i);
    onChangeSelected(pages);
  };

  const selectAll = () => {
    onChangeSelected(Array.from({ length: totalPages }, (_, i) => i + 1));
  };

  const clearAll = () => onChangeSelected([]);

  const handleRangeInput = (value: string) => {
    if (!value.trim()) {
      onChangeSelected([]);
      return;
    }
    onChangeSelected(parsePageRanges(value, totalPages));
  };

  const rangeSummary = formatPageSelectionSummary(selectedPages);

  return (
    <div className="space-y-4">
      {/* Selection Controls Bar */}
      <div className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-3.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {mode === 'extract' && (
            <button
              type="button"
              onClick={selectAll}
              className="rounded-md border border-zinc-200 bg-white px-2.5 py-1 text-xs font-medium text-zinc-700 hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
            >
              All
            </button>
          )}
          <button
            type="button"
            onClick={selectOdd}
            className="rounded-md border border-zinc-200 bg-white px-2.5 py-1 text-xs font-medium text-zinc-700 hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Odd Pages
          </button>
          <button
            type="button"
            onClick={selectEven}
            className="rounded-md border border-zinc-200 bg-white px-2.5 py-1 text-xs font-medium text-zinc-700 hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Even Pages
          </button>
          <button
            type="button"
            onClick={clearAll}
            className="rounded-md border border-zinc-200 bg-white px-2.5 py-1 text-xs font-medium text-zinc-700 hover:border-zinc-300 hover:text-zinc-950 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Clear
          </button>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="page-range-box" className="text-xs font-medium text-zinc-500 shrink-0">
            Pages:
          </label>
          <input
            id="page-range-box"
            type="text"
            value={rangeSummary}
            onChange={(e) => handleRangeInput(e.target.value)}
            placeholder={`e.g. 1-3, ${Math.min(5, totalPages)}`}
            className="w-full sm:w-44 rounded-md border border-zinc-200 bg-white px-2.5 py-1 text-xs font-mono text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none"
          />
        </div>
      </div>

      {/* Status Summary */}
      <div className="flex items-center justify-between text-xs text-zinc-500">
        <span>
          {mode === 'remove'
            ? 'Click pages you want to delete from the PDF.'
            : 'Click pages you want to extract from the PDF.'}
        </span>
        <span className="font-mono tabular-nums font-medium text-zinc-700">
          {selectedPages.length} / {totalPages} selected
        </span>
      </div>

      {/* Thumbnail Grid */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5">
        {Array.from({ length: totalPages }, (_, idx) => {
          const pageNum = idx + 1;
          const thumb = thumbnails.find((t) => t.pageNumber === pageNum);
          const isSelected = selectedSet.has(pageNum);

          return (
            <motion.button
              key={pageNum}
              type="button"
              onClick={() => togglePage(pageNum)}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.12 }}
              className={`group relative flex flex-col overflow-hidden rounded-lg border text-left transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600 ${
                isSelected
                  ? mode === 'remove'
                    ? 'border-rose-500 bg-rose-50/40'
                    : 'border-zinc-900 bg-zinc-50'
                  : 'border-zinc-200 bg-white hover:border-zinc-400'
              }`}
            >
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-zinc-100">
                {thumb ? (
                  <img
                    src={thumb.dataUrl}
                    alt={`Page ${pageNum}`}
                    referrerPolicy="no-referrer"
                    className={`h-full w-full object-contain bg-white transition-opacity duration-150 ${
                      isSelected && mode === 'remove' ? 'opacity-40 grayscale' : 'opacity-100'
                    }`}
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-zinc-100 text-xs font-mono text-zinc-400">
                    {isRendering ? `Rendering ${pageNum}…` : `Page ${pageNum}`}
                  </div>
                )}

                {isSelected && (
                  <div
                    className={`absolute inset-x-0 top-0 flex items-center justify-between px-2 py-1 text-[11px] font-medium ${
                      mode === 'remove'
                        ? 'bg-rose-600 text-white'
                        : 'bg-zinc-900 text-white'
                    }`}
                  >
                    <span>{mode === 'remove' ? 'Remove' : 'Extract'}</span>
                    {mode === 'remove' ? (
                      <Trash2 className="h-3 w-3" aria-hidden="true" />
                    ) : (
                      <Check className="h-3 w-3" aria-hidden="true" />
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between border-t border-zinc-100 px-2.5 py-1.5 text-xs">
                <span className="font-mono tabular-nums text-zinc-700">Page {pageNum}</span>
                <span className="text-zinc-400">
                  {isSelected ? (mode === 'remove' ? 'Marked' : 'Picked') : 'Keep'}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
