import {
  FileImage,
  FileOutput,
  FileSpreadsheet,
  FileText,
  Image as ImageIcon,
  Layers,
  Presentation,
  Scissors,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { TOOL_CATEGORIES, TOOLS_CATALOG } from '../data/toolsCatalog';
import type { ToolId } from '../types/tools';

interface ToolSidebarProps {
  activeToolId: ToolId;
  onSelectTool: (id: ToolId) => void;
}

export function getToolIcon(id: ToolId) {
  switch (id) {
    case 'images-to-pdf':
      return ImageIcon;
    case 'pdf-to-images':
      return FileImage;
    case 'merge-pdf':
      return Layers;
    case 'split-pdf':
      return Scissors;
    case 'remove-pages':
      return Trash2;
    case 'extract-pages':
      return FileOutput;
    case 'pdf-to-word':
    case 'word-to-pdf':
      return FileText;
    case 'excel-to-pdf':
    case 'pdf-to-excel':
      return FileSpreadsheet;
    case 'pptx-to-pdf':
    case 'pdf-to-pptx':
      return Presentation;
  }
}

export function ToolSidebar({ activeToolId, onSelectTool }: ToolSidebarProps) {
  return (
    <aside aria-label="PDF tools" className="w-full lg:w-[264px] shrink-0">
      {/* Mobile / Tablet compact horizontal tool selector */}
      <div className="lg:hidden mb-4">
        <label htmlFor="mobile-tool-select" className="sr-only">
          Choose PDF tool
        </label>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {TOOLS_CATALOG.map((tool) => {
            const Icon = getToolIcon(tool.id);
            const isActive = tool.id === activeToolId;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => onSelectTool(tool.id)}
                className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'border-zinc-900 bg-zinc-900 text-white'
                    : 'border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300 hover:text-zinc-950'
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                <span>{tool.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Desktop Studio Rail */}
      <div className="hidden lg:block rounded-xl border border-zinc-200 bg-white p-3">
        <div className="space-y-5">
          {TOOL_CATEGORIES.map((category, idx) => {
            const tools = TOOLS_CATALOG.filter((t) => t.category === category.id);
            return (
              <div
                key={category.id}
                className={idx > 0 ? 'border-t border-zinc-100 pt-4' : 'pt-1'}
              >
                <p className="px-2.5 pb-2 text-xs font-semibold tracking-tight text-zinc-400">
                  {category.label}
                </p>
                <div className="space-y-0.5">
                  {tools.map((tool) => {
                    const Icon = getToolIcon(tool.id);
                    const isActive = tool.id === activeToolId;
                    return (
                      <button
                        key={tool.id}
                        type="button"
                        onClick={() => onSelectTool(tool.id)}
                        className={`relative flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-rose-600 ${
                          isActive
                            ? 'font-medium text-zinc-950'
                            : 'font-normal text-zinc-600 hover:bg-zinc-50 hover:text-zinc-950'
                        }`}
                      >
                        {isActive && (
                          <motion.span
                            layoutId="active-tool-pill"
                            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                            className="absolute inset-0 rounded-lg bg-zinc-100"
                            aria-hidden="true"
                          />
                        )}
                        <Icon
                          className={`relative z-10 h-4 w-4 shrink-0 transition-colors ${
                            isActive ? 'text-rose-600' : 'text-zinc-400'
                          }`}
                          aria-hidden="true"
                        />
                        <span className="relative z-10 truncate">{tool.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
