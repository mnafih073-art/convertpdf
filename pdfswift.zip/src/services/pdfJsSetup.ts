import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import type { PdfPageThumbnail } from '../types/tools';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;

export interface ExtractedTextRun {
  str: string;
  x: number;
  y: number;
  fontSize: number;
  width: number;
}

export interface ExtractedLine {
  y: number;
  text: string;
  avgFontSize: number;
  runs: ExtractedTextRun[];
}

export interface ExtractedPageContent {
  pageNumber: number;
  width: number;
  height: number;
  lines: ExtractedLine[];
  plainText: string;
}

export async function loadPdfDocument(buffer: ArrayBuffer) {
  const copy = buffer.slice(0);
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(copy) });
  return loadingTask.promise;
}

export async function getPdfPageCount(file: File): Promise<number> {
  const buffer = await file.arrayBuffer();
  const doc = await loadPdfDocument(buffer);
  const count = doc.numPages;
  await doc.cleanup();
  return count;
}

export async function renderPdfPageToBlob(
  pdfDoc: pdfjsLib.PDFDocumentProxy,
  pageNumber: number,
  scale: number,
  format: 'jpg' | 'png' | 'webp' = 'jpg',
  quality = 0.92
): Promise<{ blob: Blob; dataUrl: string; width: number; height: number }> {
  const page = await pdfDoc.getPage(pageNumber);
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(viewport.width));
  canvas.height = Math.max(1, Math.round(viewport.height));

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize 2D canvas context.');
  }

  // Fill crisp white background for JPG or transparent PDF pages
  if (format === 'jpg') {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  await page.render({ canvasContext: ctx, viewport, canvas }).promise;

  const mimeType =
    format === 'png'
      ? 'image/png'
      : format === 'webp'
      ? 'image/webp'
      : 'image/jpeg';

  const dataUrl = canvas.toDataURL(mimeType, quality);
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => {
        if (b) resolve(b);
        else reject(new Error('Failed to encode image from PDF page.'));
      },
      mimeType,
      quality
    );
  });

  page.cleanup();
  return { blob, dataUrl, width: canvas.width, height: canvas.height };
}

export async function renderPdfThumbnails(
  file: File,
  targetWidth = 220,
  onPageRendered?: (thumb: PdfPageThumbnail, total: number) => void
): Promise<PdfPageThumbnail[]> {
  const buffer = await file.arrayBuffer();
  const doc = await loadPdfDocument(buffer);
  const total = doc.numPages;
  const thumbnails: PdfPageThumbnail[] = [];

  try {
    for (let i = 1; i <= total; i++) {
      const page = await doc.getPage(i);
      const baseViewport = page.getViewport({ scale: 1 });
      const scale = Math.min(1.5, Math.max(0.2, targetWidth / baseViewport.width));
      const viewport = page.getViewport({ scale });

      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(viewport.width));
      canvas.height = Math.max(1, Math.round(viewport.height));
      const ctx = canvas.getContext('2d');

      if (ctx) {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({ canvasContext: ctx, viewport, canvas }).promise;
      }

      const thumb: PdfPageThumbnail = {
        pageNumber: i,
        dataUrl: canvas.toDataURL('image/jpeg', 0.82),
        width: canvas.width,
        height: canvas.height,
      };
      thumbnails.push(thumb);
      onPageRendered?.(thumb, total);
      page.cleanup();
    }
  } finally {
    await doc.cleanup();
  }

  return thumbnails;
}

export async function extractStructuredPdfContent(
  file: File,
  onProgress?: (current: number, total: number) => void
): Promise<ExtractedPageContent[]> {
  const buffer = await file.arrayBuffer();
  const doc = await loadPdfDocument(buffer);
  const total = doc.numPages;
  const pages: ExtractedPageContent[] = [];

  try {
    for (let pageNum = 1; pageNum <= total; pageNum++) {
      onProgress?.(pageNum, total);
      const page = await doc.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1 });
      const textContent = await page.getTextContent();

      const runs: ExtractedTextRun[] = [];
      for (const item of textContent.items) {
        if ('str' in item && item.str.trim().length > 0) {
          const tx = item.transform;
          const fontSize = Math.hypot(tx[0], tx[1]) || Math.abs(tx[3]) || 11;
          runs.push({
            str: item.str,
            x: tx[4],
            y: viewport.height - tx[5],
            fontSize,
            width: item.width || item.str.length * fontSize * 0.5,
          });
        }
      }

      // Group text runs into visual lines by Y coordinate
      runs.sort((a, b) => a.y - b.y || a.x - b.x);
      const lines: ExtractedLine[] = [];
      const yTolerance = 4.5;

      for (const run of runs) {
        const existingLine = lines.find((line) => Math.abs(line.y - run.y) <= yTolerance);
        if (existingLine) {
          existingLine.runs.push(run);
        } else {
          lines.push({
            y: run.y,
            text: '',
            avgFontSize: run.fontSize,
            runs: [run],
          });
        }
      }

      for (const line of lines) {
        line.runs.sort((a, b) => a.x - b.x);
        let built = '';
        let prevEnd = -1;
        let sizeSum = 0;

        for (const r of line.runs) {
          if (prevEnd >= 0 && r.x - prevEnd > Math.max(2, r.fontSize * 0.28)) {
            built += ' ';
          }
          built += r.str;
          prevEnd = r.x + r.width;
          sizeSum += r.fontSize;
        }
        line.text = built.replace(/\s+/g, ' ').trim();
        line.avgFontSize = line.runs.length > 0 ? sizeSum / line.runs.length : 11;
      }

      const filteredLines = lines.filter((l) => l.text.length > 0);
      pages.push({
        pageNumber: pageNum,
        width: viewport.width,
        height: viewport.height,
        lines: filteredLines,
        plainText: filteredLines.map((l) => l.text).join('\n'),
      });
      page.cleanup();
    }
  } finally {
    await doc.cleanup();
  }

  return pages;
}
