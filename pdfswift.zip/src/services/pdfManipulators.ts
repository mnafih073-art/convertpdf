import JSZip from 'jszip';
import { PageSizes, PDFDocument } from 'pdf-lib';
import type {
  ConversionResult,
  GeneratedOutputFile,
  ImageToPdfOptions,
  SplitPdfOptions,
} from '../types/tools';
import {
  formatPageSelectionSummary,
  parseSplitGroups,
  stripExtension,
} from '../utils/formatters';

interface DecodedImageResult {
  bytes: Uint8Array;
  format: 'png' | 'jpg';
  width: number;
  height: number;
}

async function decodeImageForPdf(file: File): Promise<DecodedImageResult> {
  const lowerName = file.name.toLowerCase();
  const isSvg = file.type === 'image/svg+xml' || lowerName.endsWith('.svg');
  const isJpeg =
    file.type === 'image/jpeg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg');
  const isPng = file.type === 'image/png' || lowerName.endsWith('.png');

  // Fast path for standard PNG & JPEG unless we want canvas fallback
  if (isJpeg || isPng) {
    try {
      const buffer = await file.arrayBuffer();
      const dims = await getImageDimensionsFromFile(file);
      return {
        bytes: new Uint8Array(buffer),
        format: isJpeg ? 'jpg' : 'png',
        width: dims.width,
        height: dims.height,
      };
    } catch {
      // Fallback to canvas rasterization below
    }
  }

  // Handle SVG, WEBP, or unusual encodings via Canvas
  const objectUrl = isSvg
    ? await createNormalizedSvgUrl(file)
    : URL.createObjectURL(file);

  try {
    const img = await loadHtmlImage(objectUrl);
    const naturalW = img.naturalWidth || 1200;
    const naturalH = img.naturalHeight || 900;

    // Upscale SVGs crisply while keeping raster files bounded
    const scale = isSvg ? Math.max(2, Math.min(4, 2000 / Math.max(naturalW, 1))) : 1;
    const targetW = Math.min(3600, Math.max(1, Math.round(naturalW * scale)));
    const targetH = Math.min(3600, Math.max(1, Math.round(naturalH * scale)));

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Unable to initialize canvas for image conversion.');

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, targetW, targetH);
    ctx.drawImage(img, 0, 0, targetW, targetH);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error(`Failed to rasterize ${file.name}.`))),
        'image/png',
        0.95
      );
    });

    return {
      bytes: new Uint8Array(await blob.arrayBuffer()),
      format: 'png',
      width: targetW,
      height: targetH,
    };
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

async function createNormalizedSvgUrl(file: File): Promise<string> {
  const rawText = await file.text();
  const parser = new DOMParser();
  const doc = parser.parseFromString(rawText, 'image/svg+xml');
  const svgEl = doc.documentElement;

  if (svgEl && svgEl.tagName.toLowerCase() === 'svg') {
    const hasWidth = svgEl.getAttribute('width');
    const hasHeight = svgEl.getAttribute('height');
    const viewBox = svgEl.getAttribute('viewBox');

    if ((!hasWidth || !hasHeight || hasWidth.includes('%') || hasHeight.includes('%')) && viewBox) {
      const parts = viewBox.trim().split(/[\s,]+/).map(Number);
      if (parts.length === 4 && parts[2] > 0 && parts[3] > 0) {
        svgEl.setAttribute('width', `${parts[2]}`);
        svgEl.setAttribute('height', `${parts[3]}`);
      }
    } else if (!hasWidth || !hasHeight) {
      svgEl.setAttribute('width', '1200');
      svgEl.setAttribute('height', '900');
    }

    const serialized = new XMLSerializer().serializeToString(svgEl);
    const blob = new Blob([serialized], { type: 'image/svg+xml;charset=utf-8' });
    return URL.createObjectURL(blob);
  }

  return URL.createObjectURL(file);
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to decode image file.'));
    img.src = src;
  });
}

async function getImageDimensionsFromFile(file: File): Promise<{ width: number; height: number }> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadHtmlImage(url);
    return {
      width: img.naturalWidth || 1000,
      height: img.naturalHeight || 1000,
    };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function imagesToPdf(
  files: File[],
  options: ImageToPdfOptions,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  if (files.length === 0) throw new Error('Please add at least one image.');

  const pdfDoc = await PDFDocument.create();
  const marginPt = options.margin === 'none' ? 0 : options.margin === 'compact' ? 20 : 42;

  for (let i = 0; i < files.length; i++) {
    onProgress?.(Math.round(((i + 0.2) / files.length) * 90));
    const decoded = await decodeImageForPdf(files[i]);

    let embedded;
    try {
      embedded =
        decoded.format === 'jpg'
          ? await pdfDoc.embedJpg(decoded.bytes)
          : await pdfDoc.embedPng(decoded.bytes);
    } catch {
      // If a JPEG has CMYK or PNG has unsupported chunks, re-encode via canvas as PNG
      const fallbackUrl = URL.createObjectURL(files[i]);
      try {
        const img = await loadHtmlImage(fallbackUrl);
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || 1200;
        canvas.height = img.naturalHeight || 900;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Canvas unavailable.');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        const pngBlob = await new Promise<Blob>((res, rej) =>
          canvas.toBlob((b) => (b ? res(b) : rej(new Error('PNG fallback failed.'))), 'image/png')
        );
        embedded = await pdfDoc.embedPng(new Uint8Array(await pngBlob.arrayBuffer()));
      } finally {
        URL.revokeObjectURL(fallbackUrl);
      }
    }

    const imgW = embedded.width;
    const imgH = embedded.height;

    let pageW: number;
    let pageH: number;

    if (options.pageSize === 'fit') {
      pageW = imgW + marginPt * 2;
      pageH = imgH + marginPt * 2;
    } else {
      const base = options.pageSize === 'a4' ? PageSizes.A4 : PageSizes.Letter;
      const isLandscape =
        options.orientation === 'landscape' ||
        (options.orientation === 'auto' && imgW > imgH);
      pageW = isLandscape ? base[1] : base[0];
      pageH = isLandscape ? base[0] : base[1];
    }

    const page = pdfDoc.addPage([pageW, pageH]);
    const availW = Math.max(10, pageW - marginPt * 2);
    const availH = Math.max(10, pageH - marginPt * 2);
    const scale = Math.min(availW / imgW, availH / imgH);
    const drawW = imgW * scale;
    const drawH = imgH * scale;

    page.drawImage(embedded, {
      x: (pageW - drawW) / 2,
      y: (pageH - drawH) / 2,
      width: drawW,
      height: drawH,
    });
  }

  onProgress?.(96);
  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([new Uint8Array(pdfBytes)], { type: 'application/pdf' });
  const baseName = files.length === 1 ? stripExtension(files[0].name) : 'pdfswift-images';
  const name = `${baseName}.pdf`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Converted ${files.length} image${files.length === 1 ? '' : 's'} into a ${files.length}-page PDF.`,
  };
}

export async function mergePdfs(
  files: File[],
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  if (files.length < 2) {
    throw new Error('Please upload at least 2 PDF files to merge.');
  }

  const mergedPdf = await PDFDocument.create();
  let totalPages = 0;

  for (let i = 0; i < files.length; i++) {
    onProgress?.(Math.round(((i + 0.3) / files.length) * 90));
    const buffer = await files[i].arrayBuffer();
    let srcPdf: PDFDocument;
    try {
      srcPdf = await PDFDocument.load(buffer);
    } catch {
      throw new Error(`Could not read "${files[i].name}". Ensure it is not password-protected.`);
    }

    const copiedPages = await mergedPdf.copyPages(srcPdf, srcPdf.getPageIndices());
    for (const page of copiedPages) {
      mergedPdf.addPage(page);
    }
    totalPages += copiedPages.length;
  }

  onProgress?.(96);
  const bytes = await mergedPdf.save();
  const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
  const name = `${stripExtension(files[0].name)}-merged.pdf`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Merged ${files.length} PDF files (${totalPages} total pages).`,
  };
}

export async function splitPdf(
  file: File,
  options: SplitPdfOptions,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const buffer = await file.arrayBuffer();
  const srcPdf = await PDFDocument.load(buffer);
  const totalPages = srcPdf.getPageCount();
  const baseName = stripExtension(file.name);

  let groups: number[][] = [];

  if (options.mode === 'every-page') {
    groups = Array.from({ length: totalPages }, (_, idx) => [idx + 1]);
  } else if (options.mode === 'interval') {
    const step = Math.max(1, Math.min(totalPages, options.interval || 1));
    for (let start = 1; start <= totalPages; start += step) {
      const chunk: number[] = [];
      for (let p = start; p < start + step && p <= totalPages; p++) {
        chunk.push(p);
      }
      groups.push(chunk);
    }
  } else {
    groups = parseSplitGroups(options.ranges, totalPages);
    if (groups.length === 0) {
      throw new Error(`Enter valid page ranges between 1 and ${totalPages} (for example: 1-3, 4-6).`);
    }
  }

  const outputs: GeneratedOutputFile[] = [];
  const zip = new JSZip();

  for (let i = 0; i < groups.length; i++) {
    onProgress?.(Math.round(((i + 0.5) / groups.length) * 85));
    const pageNums = groups[i];
    const outPdf = await PDFDocument.create();
    const indices = pageNums.map((p) => p - 1);
    const copied = await outPdf.copyPages(srcPdf, indices);
    copied.forEach((p) => outPdf.addPage(p));

    const bytes = await outPdf.save();
    const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
    const rangeLabel =
      pageNums.length === 1 ? `page-${pageNums[0]}` : `pages-${pageNums[0]}-${pageNums[pageNums.length - 1]}`;
    const filename = `${baseName}-${rangeLabel}.pdf`;
    outputs.push({ name: filename, blob, size: blob.size });
    zip.file(filename, bytes);
  }

  onProgress?.(94);
  if (outputs.length === 1) {
    onProgress?.(100);
    return {
      primaryFile: outputs[0],
      summary: `Split into 1 PDF containing ${groups[0].length} page(s).`,
    };
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const zipFile: GeneratedOutputFile = {
    name: `${baseName}-split.zip`,
    blob: zipBlob,
    size: zipBlob.size,
  };

  onProgress?.(100);
  return {
    primaryFile: zipFile,
    extraFiles: outputs,
    zipFile,
    summary: `Split ${totalPages}-page PDF into ${outputs.length} separate PDF files.`,
  };
}

export async function removePdfPages(
  file: File,
  pagesToRemove: number[],
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const buffer = await file.arrayBuffer();
  const srcPdf = await PDFDocument.load(buffer);
  const totalPages = srcPdf.getPageCount();
  const removeSet = new Set(pagesToRemove);

  const keepIndices: number[] = [];
  for (let p = 1; p <= totalPages; p++) {
    if (!removeSet.has(p)) {
      keepIndices.push(p - 1);
    }
  }

  if (keepIndices.length === 0) {
    throw new Error('Cannot remove every page. Leave at least one page in the document.');
  }
  if (keepIndices.length === totalPages) {
    throw new Error('Select at least one page to remove.');
  }

  onProgress?.(55);
  const outPdf = await PDFDocument.create();
  const copied = await outPdf.copyPages(srcPdf, keepIndices);
  copied.forEach((p) => outPdf.addPage(p));

  onProgress?.(92);
  const bytes = await outPdf.save();
  const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
  const name = `${stripExtension(file.name)}-trimmed.pdf`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Removed ${totalPages - keepIndices.length} page(s). ${keepIndices.length} page(s) remaining.`,
  };
}

export async function extractPdfPages(
  file: File,
  pagesToExtract: number[],
  separateFiles: boolean,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  if (pagesToExtract.length === 0) {
    throw new Error('Select at least one page to extract.');
  }

  const buffer = await file.arrayBuffer();
  const srcPdf = await PDFDocument.load(buffer);
  const totalPages = srcPdf.getPageCount();
  const validPages = pagesToExtract
    .filter((p) => p >= 1 && p <= totalPages)
    .sort((a, b) => a - b);

  if (validPages.length === 0) {
    throw new Error('Selected page numbers are out of range.');
  }

  const baseName = stripExtension(file.name);

  if (!separateFiles || validPages.length === 1) {
    onProgress?.(60);
    const outPdf = await PDFDocument.create();
    const copied = await outPdf.copyPages(
      srcPdf,
      validPages.map((p) => p - 1)
    );
    copied.forEach((p) => outPdf.addPage(p));

    const bytes = await outPdf.save();
    const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
    const name = `${baseName}-extracted.pdf`;

    onProgress?.(100);
    return {
      primaryFile: { name, blob, size: blob.size },
      summary: `Extracted ${validPages.length} page(s) (${formatPageSelectionSummary(validPages)}) into a new PDF.`,
    };
  }

  const zip = new JSZip();
  const outputs: GeneratedOutputFile[] = [];

  for (let i = 0; i < validPages.length; i++) {
    onProgress?.(Math.round(((i + 0.5) / validPages.length) * 85));
    const pageNum = validPages[i];
    const outPdf = await PDFDocument.create();
    const [copied] = await outPdf.copyPages(srcPdf, [pageNum - 1]);
    outPdf.addPage(copied);
    const bytes = await outPdf.save();
    const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
    const filename = `${baseName}-page-${pageNum}.pdf`;
    outputs.push({ name: filename, blob, size: blob.size });
    zip.file(filename, bytes);
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const zipFile: GeneratedOutputFile = {
    name: `${baseName}-extracted-pages.zip`,
    blob: zipBlob,
    size: zipBlob.size,
  };

  onProgress?.(100);
  return {
    primaryFile: zipFile,
    extraFiles: outputs,
    zipFile,
    summary: `Extracted ${validPages.length} individual PDF pages into a ZIP archive.`,
  };
}
