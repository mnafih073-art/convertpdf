import {
  Document,
  HeadingLevel,
  ImageRun,
  Packer,
  PageBreak,
  Paragraph,
  TextRun,
} from 'docx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import JSZip from 'jszip';
import mammoth from 'mammoth/mammoth.browser';
import { PDFDocument } from 'pdf-lib';
import PptxGenJS from 'pptxgenjs';
import * as XLSX from 'xlsx';
import type {
  ConversionResult,
  ExcelToPdfOptions,
  GeneratedOutputFile,
  PdfToImageOptions,
} from '../types/tools';
import { parsePageRanges, stripExtension } from '../utils/formatters';
import {
  extractStructuredPdfContent,
  loadPdfDocument,
  renderPdfPageToBlob,
} from './pdfJsSetup';

export async function pdfToImages(
  file: File,
  options: PdfToImageOptions,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const buffer = await file.arrayBuffer();
  const doc = await loadPdfDocument(buffer);
  const totalPages = doc.numPages;
  const baseName = stripExtension(file.name);

  try {
    const targetPages =
      options.ranges.trim().length > 0
        ? parsePageRanges(options.ranges, totalPages)
        : Array.from({ length: totalPages }, (_, i) => i + 1);

    if (targetPages.length === 0) {
      throw new Error(`Specify valid pages between 1 and ${totalPages}, or leave blank for all pages.`);
    }

    const scale = options.dpi / 72;
    const outputs: GeneratedOutputFile[] = [];
    const zip = new JSZip();

    for (let i = 0; i < targetPages.length; i++) {
      onProgress?.(Math.round(((i + 0.3) / targetPages.length) * 88));
      const pageNum = targetPages[i];
      const rendered = await renderPdfPageToBlob(doc, pageNum, scale, options.format, 0.92);
      const filename = `${baseName}-page-${pageNum}.${options.format}`;
      outputs.push({
        name: filename,
        blob: rendered.blob,
        size: rendered.blob.size,
        previewUrl: rendered.dataUrl,
      });
      zip.file(filename, rendered.blob);
    }

    onProgress?.(95);
    if (outputs.length === 1) {
      onProgress?.(100);
      return {
        primaryFile: outputs[0],
        extraFiles: outputs,
        summary: `Exported page ${targetPages[0]} as ${options.format.toUpperCase()} (${options.dpi} DPI).`,
      };
    }

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const zipFile: GeneratedOutputFile = {
      name: `${baseName}-${options.format}.zip`,
      blob: zipBlob,
      size: zipBlob.size,
    };

    onProgress?.(100);
    return {
      primaryFile: zipFile,
      extraFiles: outputs,
      zipFile,
      summary: `Exported ${outputs.length} pages as ${options.format.toUpperCase()} images (${options.dpi} DPI).`,
    };
  } finally {
    await doc.cleanup();
  }
}

export async function pdfToWord(
  file: File,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const pages = await extractStructuredPdfContent(file, (curr, total) => {
    onProgress?.(Math.round((curr / total) * 65));
  });

  // Compute median font size across document to classify headings vs body text
  const allFontSizes: number[] = [];
  for (const p of pages) {
    for (const l of p.lines) {
      allFontSizes.push(l.avgFontSize);
    }
  }
  allFontSizes.sort((a, b) => a - b);
  const medianSize =
    allFontSizes.length > 0 ? allFontSizes[Math.floor(allFontSizes.length / 2)] : 11;

  // Check if document has scanned/image-only pages needing image fallback
  const hasEmptyTextPages = pages.some((p) => p.lines.length === 0);
  let pdfDocForImages: Awaited<ReturnType<typeof loadPdfDocument>> | null = null;
  if (hasEmptyTextPages) {
    pdfDocForImages = await loadPdfDocument(await file.arrayBuffer());
  }

  const children: Paragraph[] = [];

  try {
    for (let idx = 0; idx < pages.length; idx++) {
      onProgress?.(65 + Math.round(((idx + 1) / pages.length) * 25));
      const page = pages[idx];

      if (idx > 0) {
        children.push(new Paragraph({ children: [new PageBreak()] }));
      }

      if (page.lines.length === 0 && pdfDocForImages) {
        // Scanned/image-only page fallback: embed rendered PNG snapshot so Word doc is never blank
        const rendered = await renderPdfPageToBlob(pdfDocForImages, page.pageNumber, 1.8, 'png');
        const imgBytes = new Uint8Array(await rendered.blob.arrayBuffer());
        const maxWidthPx = 560;
        const ratio = rendered.height / Math.max(rendered.width, 1);
        children.push(
          new Paragraph({
            children: [
              new ImageRun({
                data: imgBytes,
                transformation: {
                  width: maxWidthPx,
                  height: Math.round(maxWidthPx * ratio),
                },
                type: 'png',
              }),
            ],
          })
        );
        continue;
      }

      let paragraphBuffer: string[] = [];
      let prevY = -1;

      const flushBuffer = () => {
        if (paragraphBuffer.length > 0) {
          children.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: paragraphBuffer.join(' '),
                  size: 22,
                }),
              ],
              spacing: { after: 140 },
            })
          );
          paragraphBuffer = [];
        }
      };

      for (const line of page.lines) {
        const isHeading1 = line.avgFontSize >= medianSize * 1.45 && line.text.length <= 120;
        const isHeading2 =
          !isHeading1 && line.avgFontSize >= medianSize * 1.2 && line.text.length <= 120;
        const isBullet = /^[•\-*\u2022]\s+/.test(line.text);
        const yGap = prevY >= 0 ? line.y - prevY : 0;

        if (isHeading1 || isHeading2) {
          flushBuffer();
          children.push(
            new Paragraph({
              text: line.text,
              heading: isHeading1 ? HeadingLevel.HEADING_1 : HeadingLevel.HEADING_2,
              spacing: { before: 200, after: 120 },
            })
          );
        } else if (isBullet) {
          flushBuffer();
          children.push(
            new Paragraph({
              text: line.text.replace(/^[•\-*\u2022]\s+/, ''),
              bullet: { level: 0 },
              spacing: { after: 80 },
            })
          );
        } else {
          if (prevY >= 0 && yGap > line.avgFontSize * 1.8) {
            flushBuffer();
          }
          paragraphBuffer.push(line.text);
        }

        prevY = line.y;
      }

      flushBuffer();
    }
  } finally {
    if (pdfDocForImages) {
      await pdfDocForImages.cleanup();
    }
  }

  const wordDoc = new Document({
    sections: [
      {
        properties: {},
        children,
      },
    ],
  });

  onProgress?.(94);
  const blob = await Packer.toBlob(wordDoc);
  const name = `${stripExtension(file.name)}.docx`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Converted ${pages.length}-page PDF to an editable Word (.docx) document.`,
  };
}

export async function wordToPdf(
  file: File,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  onProgress?.(25);
  const buffer = await file.arrayBuffer();
  const result = await mammoth.convertToHtml({ arrayBuffer: buffer });

  onProgress?.(55);
  const parsed = new DOMParser().parseFromString(result.value, 'text/html');
  const pdf = new jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });

  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 48;
  const maxW = pageW - margin * 2;
  let cursorY = margin;

  const ensureSpace = (needed: number) => {
    if (cursorY + needed > pageH - margin) {
      pdf.addPage();
      cursorY = margin;
    }
  };

  const renderTextBlock = (
    text: string,
    fontSize: number,
    fontStyle: 'normal' | 'bold' | 'italic',
    gapAfter = 10,
    indent = 0
  ) => {
    const clean = text.replace(/\s+/g, ' ').trim();
    if (!clean) return;
    pdf.setFont('helvetica', fontStyle);
    pdf.setFontSize(fontSize);
    pdf.setTextColor(24, 24, 27);
    const lines = pdf.splitTextToSize(clean, maxW - indent) as string[];
    const lineHeight = fontSize * 1.42;

    for (const line of lines) {
      ensureSpace(lineHeight);
      pdf.text(line, margin + indent, cursorY);
      cursorY += lineHeight;
    }
    cursorY += gapAfter;
  };

  const walkNode = async (el: Element) => {
    const tag = el.tagName.toLowerCase();

    if (tag === 'h1') {
      renderTextBlock(el.textContent || '', 20, 'bold', 12);
    } else if (tag === 'h2') {
      renderTextBlock(el.textContent || '', 16, 'bold', 10);
    } else if (tag === 'h3' || tag === 'h4') {
      renderTextBlock(el.textContent || '', 13, 'bold', 8);
    } else if (tag === 'p') {
      const img = el.querySelector('img');
      if (img && img.src.startsWith('data:image/')) {
        await embedDataUrlImage(pdf, img.src, margin, maxW, pageH, () => cursorY, (y) => {
          cursorY = y;
        });
      }
      renderTextBlock(el.textContent || '', 11, 'normal', 9);
    } else if (tag === 'ul' || tag === 'ol') {
      const items = Array.from(el.children).filter((c) => c.tagName.toLowerCase() === 'li');
      items.forEach((li, index) => {
        const prefix = tag === 'ol' ? `${index + 1}. ` : '• ';
        renderTextBlock(`${prefix}${li.textContent || ''}`, 11, 'normal', 5, 14);
      });
      cursorY += 5;
    } else if (tag === 'table') {
      const rows = Array.from(el.querySelectorAll('tr')).map((tr) =>
        Array.from(tr.querySelectorAll('th, td')).map((cell) => (cell.textContent || '').trim())
      );
      if (rows.length > 0) {
        const head = [rows[0]];
        const body = rows.slice(1);
        autoTable(pdf, {
          startY: cursorY,
          head: body.length > 0 ? head : undefined,
          body: body.length > 0 ? body : rows,
          margin: { left: margin, right: margin },
          styles: { fontSize: 9.5, cellPadding: 5, textColor: [24, 24, 27] },
          headStyles: { fillColor: [24, 24, 27], textColor: [255, 255, 255] },
          theme: 'grid',
        });
        const finalY = (pdf as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY;
        cursorY = (finalY ?? cursorY + 40) + 14;
      }
    } else if (tag === 'img' && (el as HTMLImageElement).src.startsWith('data:image/')) {
      await embedDataUrlImage(
        pdf,
        (el as HTMLImageElement).src,
        margin,
        maxW,
        pageH,
        () => cursorY,
        (y) => {
          cursorY = y;
        }
      );
    } else {
      for (const child of Array.from(el.children)) {
        await walkNode(child);
      }
    }
  };

  for (const child of Array.from(parsed.body.children)) {
    await walkNode(child);
  }

  onProgress?.(94);
  const blob = pdf.output('blob');
  const name = `${stripExtension(file.name)}.pdf`;
  onProgress?.(100);

  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Converted Word document into a ${pdf.getNumberOfPages()}-page PDF.`,
  };
}

async function embedDataUrlImage(
  pdf: jsPDF,
  src: string,
  margin: number,
  maxW: number,
  pageH: number,
  getY: () => number,
  setY: (y: number) => void
) {
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = reject;
      i.src = src;
    });
    const ratio = img.naturalHeight / Math.max(img.naturalWidth, 1);
    const drawW = Math.min(maxW, img.naturalWidth * 0.75);
    const drawH = Math.min(pageH - margin * 2, drawW * ratio);
    if (getY() + drawH > pageH - margin) {
      pdf.addPage();
      setY(margin);
    }
    const format = src.includes('image/png') ? 'PNG' : 'JPEG';
    pdf.addImage(src, format, margin, getY(), drawW, drawH);
    setY(getY() + drawH + 12);
  } catch {
    // Ignore unreadable embedded image
  }
}

export async function excelToPdf(
  file: File,
  options: ExcelToPdfOptions,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  onProgress?.(20);
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  if (workbook.SheetNames.length === 0) {
    throw new Error('This spreadsheet contains no readable sheets.');
  }

  const pdf = new jsPDF({
    orientation: options.orientation,
    unit: 'pt',
    format: 'a4',
  });

  let renderedSheets = 0;

  for (let i = 0; i < workbook.SheetNames.length; i++) {
    onProgress?.(25 + Math.round(((i + 1) / workbook.SheetNames.length) * 65));
    const sheetName = workbook.SheetNames[i];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(worksheet, {
      header: 1,
      defval: '',
    });

    const nonEmptyRows = rows
      .map((r) => r.map((cell) => String(cell ?? '').trim()))
      .filter((r) => r.some((cell) => cell.length > 0));

    if (nonEmptyRows.length === 0) continue;

    if (renderedSheets > 0) {
      pdf.addPage();
    }
    renderedSheets++;

    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(13);
    pdf.setTextColor(24, 24, 27);
    pdf.text(sheetName, 36, 38);

    const maxCols = Math.max(...nonEmptyRows.map((r) => r.length));
    const normalized = nonEmptyRows.map((r) => {
      const padded = [...r];
      while (padded.length < maxCols) padded.push('');
      return padded;
    });

    const head = normalized.length > 1 ? [normalized[0]] : undefined;
    const body = normalized.length > 1 ? normalized.slice(1) : normalized;

    autoTable(pdf, {
      startY: 52,
      head,
      body,
      margin: { left: 36, right: 36, top: 36, bottom: 36 },
      theme: options.includeGridlines ? 'grid' : 'plain',
      styles: {
        fontSize: 8.5,
        cellPadding: 4.5,
        overflow: 'linebreak',
        textColor: [24, 24, 27],
      },
      headStyles: {
        fillColor: [24, 24, 27],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
      },
      alternateRowStyles: {
        fillColor: [250, 250, 250],
      },
    });
  }

  if (renderedSheets === 0) {
    throw new Error('The uploaded spreadsheet appears to be empty.');
  }

  onProgress?.(95);
  const blob = pdf.output('blob');
  const name = `${stripExtension(file.name)}.pdf`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Converted ${renderedSheets} worksheet(s) into a ${pdf.getNumberOfPages()}-page PDF.`,
  };
}

export async function pdfToExcel(
  file: File,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const pages = await extractStructuredPdfContent(file, (curr, total) => {
    onProgress?.(Math.round((curr / total) * 75));
  });

  const workbook = XLSX.utils.book_new();
  let previewTable: string[][] = [];
  let totalRows = 0;

  for (const page of pages) {
    // Cluster runs by X positions into columns per line
    const tableRows: string[][] = [];
    const xStarts: number[] = [];

    for (const line of page.lines) {
      for (const run of line.runs) {
        const nearCol = xStarts.find((x) => Math.abs(x - run.x) < 18);
        if (nearCol === undefined) {
          xStarts.push(run.x);
        }
      }
    }
    xStarts.sort((a, b) => a - b);

    // Merge columns closer than 22pt
    const columns: number[] = [];
    for (const x of xStarts) {
      if (columns.length === 0 || x - columns[columns.length - 1] > 22) {
        columns.push(x);
      }
    }

    for (const line of page.lines) {
      if (columns.length <= 1) {
        tableRows.push([line.text]);
        continue;
      }

      const row = new Array<string>(columns.length).fill('');
      for (const run of line.runs) {
        let bestCol = 0;
        let bestDist = Infinity;
        for (let c = 0; c < columns.length; c++) {
          const dist = Math.abs(columns[c] - run.x);
          if (dist < bestDist) {
            bestDist = dist;
            bestCol = c;
          }
        }
        row[bestCol] = row[bestCol] ? `${row[bestCol]} ${run.str}`.trim() : run.str.trim();
      }
      if (row.some((cell) => cell.length > 0)) {
        tableRows.push(row);
      }
    }

    // Trim trailing completely empty columns
    const usedColCount = Math.max(
      1,
      ...tableRows.map((r) => {
        let last = r.length - 1;
        while (last > 0 && r[last] === '') last--;
        return last + 1;
      })
    );
    const cleanRows = tableRows.map((r) => r.slice(0, usedColCount));
    totalRows += cleanRows.length;

    if (previewTable.length === 0 && cleanRows.length > 0) {
      previewTable = cleanRows.slice(0, 8);
    }

    const ws = XLSX.utils.aoa_to_sheet(cleanRows.length > 0 ? cleanRows : [['(No selectable text found)']]);
    XLSX.utils.book_append_sheet(workbook, ws, `Page ${page.pageNumber}`.slice(0, 31));
  }

  onProgress?.(92);
  const arrayOut = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' }) as ArrayBuffer;
  const blob = new Blob([arrayOut], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const name = `${stripExtension(file.name)}.xlsx`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Extracted ${totalRows} rows across ${pages.length} sheet(s) into Excel (.xlsx).`,
    previewTable,
  };
}

export async function pptxToPdf(
  file: File,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  onProgress?.(10);
  const zip = await JSZip.loadAsync(await file.arrayBuffer());

  // Determine slide size from ppt/presentation.xml (default 16:9: 12192000 x 6858000 EMU)
  let slideWidthEmu = 12192000;
  let slideHeightEmu = 6858000;
  const orderedSlidePaths: string[] = [];

  const presXmlText = await zip.file('ppt/presentation.xml')?.async('string');
  const presRelsText = await zip.file('ppt/_rels/presentation.xml.rels')?.async('string');

  if (presXmlText) {
    const presDoc = new DOMParser().parseFromString(presXmlText, 'application/xml');
    const sldSz = presDoc.getElementsByTagName('p:sldSz')[0];
    if (sldSz) {
      const cx = Number(sldSz.getAttribute('cx'));
      const cy = Number(sldSz.getAttribute('cy'));
      if (cx > 0 && cy > 0) {
        slideWidthEmu = cx;
        slideHeightEmu = cy;
      }
    }

    if (presRelsText) {
      const relsDoc = new DOMParser().parseFromString(presRelsText, 'application/xml');
      const relMap = new Map<string, string>();
      for (const rel of Array.from(relsDoc.getElementsByTagName('Relationship'))) {
        const id = rel.getAttribute('Id');
        const target = rel.getAttribute('Target');
        if (id && target) {
          relMap.set(id, target.replace(/^\//, '').startsWith('ppt/') ? target.replace(/^\//, '') : `ppt/${target}`);
        }
      }
      for (const sldId of Array.from(presDoc.getElementsByTagName('p:sldId'))) {
        const rId = sldId.getAttribute('r:id');
        if (rId && relMap.has(rId)) {
          orderedSlidePaths.push(relMap.get(rId)!);
        }
      }
    }
  }

  // Fallback numerical sort if presentation.xml rels didn't resolve
  if (orderedSlidePaths.length === 0) {
    const slideFiles = Object.keys(zip.files)
      .filter((p) => /^ppt\/slides\/slide\d+\.xml$/.test(p))
      .sort((a, b) => {
        const numA = Number(a.match(/slide(\d+)/)?.[1] ?? 0);
        const numB = Number(b.match(/slide(\d+)/)?.[1] ?? 0);
        return numA - numB;
      });
    orderedSlidePaths.push(...slideFiles);
  }

  if (orderedSlidePaths.length === 0) {
    throw new Error('No slides found inside this PowerPoint (.pptx) file.');
  }

  const canvasW = 1600;
  const canvasH = Math.max(400, Math.round(canvasW * (slideHeightEmu / slideWidthEmu)));
  const scaleX = canvasW / slideWidthEmu;
  const scaleY = canvasH / slideHeightEmu;

  const pdfDoc = await PDFDocument.create();
  const ptW = (slideWidthEmu / 914400) * 72;
  const ptH = (slideHeightEmu / 914400) * 72;

  for (let i = 0; i < orderedSlidePaths.length; i++) {
    onProgress?.(15 + Math.round(((i + 0.5) / orderedSlidePaths.length) * 75));
    const slidePath = orderedSlidePaths[i];
    const slideXml = await zip.file(slidePath)?.async('string');
    if (!slideXml) continue;

    // Load slide relationships for embedded images
    const slideFileName = slidePath.split('/').pop()!;
    const relsPath = `ppt/slides/_rels/${slideFileName}.rels`;
    const slideRelsText = await zip.file(relsPath)?.async('string');
    const mediaRelMap = new Map<string, string>();
    if (slideRelsText) {
      const relDoc = new DOMParser().parseFromString(slideRelsText, 'application/xml');
      for (const rel of Array.from(relDoc.getElementsByTagName('Relationship'))) {
        const id = rel.getAttribute('Id');
        const target = rel.getAttribute('Target');
        if (id && target) {
          const normalizedTarget = target.replace('../', 'ppt/').replace(/^\//, '');
          mediaRelMap.set(id, normalizedTarget);
        }
      }
    }

    const slideDoc = new DOMParser().parseFromString(slideXml, 'application/xml');
    const canvas = document.createElement('canvas');
    canvas.width = canvasW;
    canvas.height = canvasH;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;

    // Default white slide background or parsed solidFill
    ctx.fillStyle = '#FFFFFF';
    const bgSolid = slideDoc.querySelector('bg srgbClr, bgPr srgbClr');
    if (bgSolid) {
      const hex = bgSolid.getAttribute('val');
      if (hex) ctx.fillStyle = `#${hex}`;
    }
    ctx.fillRect(0, 0, canvasW, canvasH);

    // Draw shapes and pictures inside spTree in document order
    const spTree = slideDoc.getElementsByTagName('p:spTree')[0];
    if (spTree) {
      for (const child of Array.from(spTree.children)) {
        const tag = child.tagName;
        if (tag === 'p:pic') {
          await drawPptxPicture(ctx, child, zip, mediaRelMap, scaleX, scaleY);
        } else if (tag === 'p:sp') {
          drawPptxShapeAndText(ctx, child, scaleX, scaleY);
        }
      }
    }

    const pngBlob = await new Promise<Blob>((res, rej) =>
      canvas.toBlob((b) => (b ? res(b) : rej(new Error('Slide render failed.'))), 'image/png')
    );
    const embedded = await pdfDoc.embedPng(new Uint8Array(await pngBlob.arrayBuffer()));
    const page = pdfDoc.addPage([ptW, ptH]);
    page.drawImage(embedded, { x: 0, y: 0, width: ptW, height: ptH });
  }

  onProgress?.(95);
  const bytes = await pdfDoc.save();
  const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
  const name = `${stripExtension(file.name)}.pdf`;

  onProgress?.(100);
  return {
    primaryFile: { name, blob, size: blob.size },
    summary: `Converted ${orderedSlidePaths.length} PowerPoint slides into a crisp PDF.`,
  };
}

async function drawPptxPicture(
  ctx: CanvasRenderingContext2D,
  picNode: Element,
  zip: JSZip,
  mediaRelMap: Map<string, string>,
  scaleX: number,
  scaleY: number
) {
  const blip = picNode.getElementsByTagName('a:blip')[0];
  const rId = blip?.getAttribute('r:embed');
  if (!rId || !mediaRelMap.has(rId)) return;

  const mediaPath = mediaRelMap.get(rId)!;
  const mediaFile = zip.file(mediaPath);
  if (!mediaFile) return;

  const xfrm = picNode.getElementsByTagName('a:xfrm')[0];
  const off = xfrm?.getElementsByTagName('a:off')[0];
  const ext = xfrm?.getElementsByTagName('a:ext')[0];
  if (!off || !ext) return;

  const x = Number(off.getAttribute('x') || 0) * scaleX;
  const y = Number(off.getAttribute('y') || 0) * scaleY;
  const w = Number(ext.getAttribute('cx') || 0) * scaleX;
  const h = Number(ext.getAttribute('cy') || 0) * scaleY;

  try {
    const imgBlob = await mediaFile.async('blob');
    const url = URL.createObjectURL(imgBlob);
    try {
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const i = new Image();
        i.onload = () => resolve(i);
        i.onerror = reject;
        i.src = url;
      });
      ctx.drawImage(img, x, y, w, h);
    } finally {
      URL.revokeObjectURL(url);
    }
  } catch {
    // Skip unsupported image formats like EMF/WMF silently
  }
}

function drawPptxShapeAndText(
  ctx: CanvasRenderingContext2D,
  spNode: Element,
  scaleX: number,
  scaleY: number
) {
  const spPr = spNode.getElementsByTagName('p:spPr')[0];
  const xfrm = spPr?.getElementsByTagName('a:xfrm')[0];
  const off = xfrm?.getElementsByTagName('a:off')[0];
  const ext = xfrm?.getElementsByTagName('a:ext')[0];
  if (!off || !ext) return;

  const x = Number(off.getAttribute('x') || 0) * scaleX;
  const y = Number(off.getAttribute('y') || 0) * scaleY;
  const w = Number(ext.getAttribute('cx') || 0) * scaleX;
  const h = Number(ext.getAttribute('cy') || 0) * scaleY;

  // Optional shape fill
  const directFill = Array.from(spPr?.children || []).find((el) => el.tagName === 'a:solidFill');
  const fillHex = directFill?.getElementsByTagName('a:srgbClr')[0]?.getAttribute('val');
  if (fillHex) {
    ctx.fillStyle = `#${fillHex}`;
    ctx.fillRect(x, y, w, h);
  }

  const txBody = spNode.getElementsByTagName('p:txBody')[0];
  if (!txBody) return;

  const paragraphs = Array.from(txBody.getElementsByTagName('a:p'));
  let cursorY = y + 18;
  const padX = 12;

  for (const para of paragraphs) {
    const runs = Array.from(para.getElementsByTagName('a:r'));
    const fullText = runs
      .map((r) => r.getElementsByTagName('a:t')[0]?.textContent || '')
      .join('')
      .trim();

    if (!fullText) {
      cursorY += 16;
      continue;
    }

    const firstRPr = runs[0]?.getElementsByTagName('a:rPr')[0];
    const szAttr = firstRPr?.getAttribute('sz');
    const fontPt = szAttr ? Number(szAttr) / 100 : 18;
    const pxSize = Math.max(12, Math.min(72, Math.round(fontPt * 1.45)));
    const isBold = firstRPr?.getAttribute('b') === '1';
    const colorHex = firstRPr?.getElementsByTagName('a:srgbClr')[0]?.getAttribute('val');
    const pPr = para.getElementsByTagName('a:pPr')[0];
    const align = pPr?.getAttribute('algn') || 'l';

    ctx.font = `${isBold ? 'bold ' : ''}${pxSize}px "Plus Jakarta Sans", Arial, sans-serif`;
    ctx.fillStyle = colorHex ? `#${colorHex}` : '#18181B';
    ctx.textBaseline = 'top';

    const maxLineW = Math.max(40, w - padX * 2);
    const words = fullText.split(/\s+/);
    let currentLine = '';
    const wrapped: string[] = [];

    for (const word of words) {
      const test = currentLine ? `${currentLine} ${word}` : word;
      if (ctx.measureText(test).width > maxLineW && currentLine) {
        wrapped.push(currentLine);
        currentLine = word;
      } else {
        currentLine = test;
      }
    }
    if (currentLine) wrapped.push(currentLine);

    for (const line of wrapped) {
      let drawX = x + padX;
      if (align === 'ctr') {
        drawX = x + (w - ctx.measureText(line).width) / 2;
      } else if (align === 'r') {
        drawX = x + w - padX - ctx.measureText(line).width;
      }
      if (cursorY < y + h) {
        ctx.fillText(line, drawX, cursorY);
      }
      cursorY += pxSize * 1.3;
    }
    cursorY += 8;
  }
}

export async function pdfToPptx(
  file: File,
  onProgress?: (pct: number) => void
): Promise<ConversionResult> {
  const buffer = await file.arrayBuffer();
  const doc = await loadPdfDocument(buffer);
  const totalPages = doc.numPages;

  try {
    const pptx = new PptxGenJS();

    // Match slide dimensions to first page aspect ratio (inches)
    const firstPage = await doc.getPage(1);
    const firstVp = firstPage.getViewport({ scale: 1 });
    const widthIn = Math.max(6, Math.min(13.333, firstVp.width / 72));
    const heightIn = Math.max(4, Math.min(10, firstVp.height / 72));
    firstPage.cleanup();

    pptx.defineLayout({ name: 'CUSTOM_PDF', width: widthIn, height: heightIn });
    pptx.layout = 'CUSTOM_PDF';

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      onProgress?.(Math.round(((pageNum - 0.3) / totalPages) * 88));
      const rendered = await renderPdfPageToBlob(doc, pageNum, 2, 'png', 0.92);
      const slide = pptx.addSlide();
      slide.addImage({
        data: rendered.dataUrl,
        x: 0,
        y: 0,
        w: widthIn,
        h: heightIn,
      });
    }

    onProgress?.(94);
    const outBlob = (await pptx.write({ outputType: 'blob' })) as Blob;
    const name = `${stripExtension(file.name)}.pptx`;

    onProgress?.(100);
    return {
      primaryFile: { name, blob: outBlob, size: outBlob.size },
      summary: `Converted ${totalPages}-page PDF into a PowerPoint (.pptx) presentation.`,
    };
  } finally {
    await doc.cleanup();
  }
}
