import { AlertCircle, ArrowRight, Loader2 } from 'lucide-react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { DropZone } from './components/DropZone';
import { FileQueueList } from './components/FileQueueList';
import { PageThumbnailGrid } from './components/PageThumbnailGrid';
import { ResultPanel } from './components/ResultPanel';
import { ToolOptionsPanel } from './components/ToolOptionsPanel';
import { ToolSidebar, getToolIcon } from './components/ToolSidebar';
import { ToolsDirectory } from './components/ToolsDirectory';
import { TopBar } from './components/TopBar';
import { getToolById } from './data/toolsCatalog';
import {
  excelToPdf,
  pdfToExcel,
  pdfToImages,
  pdfToPptx,
  pdfToWord,
  pptxToPdf,
  wordToPdf,
} from './services/pdfConverters';
import { getPdfPageCount, renderPdfThumbnails } from './services/pdfJsSetup';
import {
  extractPdfPages,
  imagesToPdf,
  mergePdfs,
  removePdfPages,
  splitPdf,
} from './services/pdfManipulators';
import type {
  ConversionResult,
  ExcelToPdfOptions,
  ImageToPdfOptions,
  PdfPageThumbnail,
  PdfToImageOptions,
  SplitPdfOptions,
  ToolCategory,
  ToolId,
  UploadedFileItem,
} from './types/tools';

function detectSuggestedToolForFile(file: File): ToolId | null {
  const lower = file.name.toLowerCase();
  if (/\.(jpg|jpeg|png|webp|svg)$/.test(lower)) return 'images-to-pdf';
  if (lower.endsWith('.docx')) return 'word-to-pdf';
  if (/\.(xlsx|xls|csv)$/.test(lower)) return 'excel-to-pdf';
  if (lower.endsWith('.pptx')) return 'pptx-to-pdf';
  if (lower.endsWith('.pdf')) return 'pdf-to-word';
  return null;
}

function fileMatchesTool(file: File, accept: string): boolean {
  const lower = file.name.toLowerCase();
  const tokens = accept.split(',').map((t) => t.trim().toLowerCase());
  return tokens.some((token) => {
    if (token.startsWith('.')) return lower.endsWith(token);
    if (file.type && token === file.type.toLowerCase()) return true;
    return false;
  });
}

export default function App() {
  const [activeToolId, setActiveToolId] = useState<ToolId>('images-to-pdf');
  const [files, setFiles] = useState<UploadedFileItem[]>([]);
  const [thumbnails, setThumbnails] = useState<PdfPageThumbnail[]>([]);
  const [isRenderingThumbs, setIsRenderingThumbs] = useState(false);
  const [selectedPages, setSelectedPages] = useState<number[]>([]);

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [suggestedToolId, setSuggestedToolId] = useState<ToolId | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Contextual tool options
  const [imageOptions, setImageOptions] = useState<ImageToPdfOptions>({
    pageSize: 'fit',
    orientation: 'auto',
    margin: 'compact',
  });
  const [splitOptions, setSplitOptions] = useState<SplitPdfOptions>({
    mode: 'every-page',
    interval: 2,
    ranges: '1-2, 3-4',
  });
  const [extractSeparate, setExtractSeparate] = useState(false);
  const [pdfToImageOptions, setPdfToImageOptions] = useState<PdfToImageOptions>({
    format: 'jpg',
    dpi: 220,
    ranges: '',
  });
  const [excelOptions, setExcelOptions] = useState<ExcelToPdfOptions>({
    orientation: 'landscape',
    includeGridlines: true,
  });

  const activeTool = getToolById(activeToolId);
  const ActiveIcon = getToolIcon(activeTool.id);

  // Clean up object URLs on unmount or clear
  const revokePreviewUrls = useCallback((items: UploadedFileItem[]) => {
    items.forEach((item) => {
      if (item.previewUrl) URL.revokeObjectURL(item.previewUrl);
    });
  }, []);

  const resetWorkspaceState = useCallback(() => {
    setFiles((prev) => {
      revokePreviewUrls(prev);
      return [];
    });
    setThumbnails([]);
    setIsRenderingThumbs(false);
    setSelectedPages([]);
    setResult(null);
    setErrorMessage(null);
    setSuggestedToolId(null);
    setProgress(0);
  }, [revokePreviewUrls]);

  const handleSelectTool = useCallback(
    (id: ToolId) => {
      if (id === activeToolId) return;
      resetWorkspaceState();
      setActiveToolId(id);
    },
    [activeToolId, resetWorkspaceState]
  );

  const handleSelectCategory = useCallback(
    (category: ToolCategory | 'all') => {
      if (category === 'to-pdf') handleSelectTool('images-to-pdf');
      else if (category === 'from-pdf') handleSelectTool('pdf-to-images');
      else if (category === 'organize') handleSelectTool('merge-pdf');
    },
    [handleSelectTool]
  );

  useEffect(() => {
    return () => {
      revokePreviewUrls(files);
    };
  }, [files, revokePreviewUrls]);

  const handleFilesAdded = useCallback(
    async (incoming: File[]) => {
      setErrorMessage(null);
      setSuggestedToolId(null);
      setResult(null);

      const accepted: File[] = [];
      const rejected: File[] = [];

      for (const f of incoming) {
        if (fileMatchesTool(f, activeTool.accept)) {
          accepted.push(f);
        } else {
          rejected.push(f);
        }
      }

      if (accepted.length === 0 && rejected.length > 0) {
        const firstRejected = rejected[0];
        const suggestion = detectSuggestedToolForFile(firstRejected);
        setSuggestedToolId(suggestion && suggestion !== activeToolId ? suggestion : null);
        setErrorMessage(
          `"${firstRejected.name}" is not supported by ${activeTool.name}. Accepted formats: ${activeTool.acceptLabel}.`
        );
        return;
      }

      if (rejected.length > 0) {
        setErrorMessage(
          `Skipped ${rejected.length} unsupported file(s). ${activeTool.name} accepts ${activeTool.acceptLabel}.`
        );
      }

      const newItems: UploadedFileItem[] = await Promise.all(
        accepted.map(async (file) => {
          const isImg =
            file.type.startsWith('image/') ||
            /\.(jpg|jpeg|png|webp|svg)$/i.test(file.name);
          const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
          let pageCount: number | undefined;
          if (isPdf) {
            try {
              pageCount = await getPdfPageCount(file);
            } catch {
              pageCount = undefined;
            }
          }
          return {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
            file,
            name: file.name,
            size: file.size,
            type: file.type,
            pageCount,
            previewUrl: isImg ? URL.createObjectURL(file) : undefined,
          };
        })
      );

      if (activeTool.multiple) {
        setFiles((prev) => [...prev, ...newItems]);
      } else {
        setFiles((prev) => {
          revokePreviewUrls(prev);
          return [newItems[0]];
        });
      }

      // If Remove Pages or Extract Pages, render visual thumbnails progressively
      if (
        (activeToolId === 'remove-pages' || activeToolId === 'extract-pages') &&
        newItems[0]
      ) {
        const pdfFile = newItems[0].file;
        setThumbnails([]);
        setSelectedPages([]);
        setIsRenderingThumbs(true);
        try {
          await renderPdfThumbnails(pdfFile, 210, (thumb) => {
            setThumbnails((prev) => [...prev, thumb]);
          });
        } catch {
          setErrorMessage(
            `Could not render pages from "${pdfFile.name}". Ensure it is a valid, unencrypted PDF.`
          );
        } finally {
          setIsRenderingThumbs(false);
        }
      }
    },
    [activeTool, activeToolId, revokePreviewUrls]
  );

  const handleMoveFile = (index: number, direction: -1 | 1) => {
    setFiles((prev) => {
      const next = [...prev];
      const target = index + direction;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => {
      const removed = prev.find((f) => f.id === id);
      if (removed?.previewUrl) URL.revokeObjectURL(removed.previewUrl);
      return prev.filter((f) => f.id !== id);
    });
    setThumbnails([]);
    setSelectedPages([]);
    setResult(null);
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    setProgress(8);
    setErrorMessage(null);
    setResult(null);

    try {
      let output: ConversionResult;
      const rawFiles = files.map((f) => f.file);

      switch (activeToolId) {
        case 'images-to-pdf':
          output = await imagesToPdf(rawFiles, imageOptions, setProgress);
          break;
        case 'merge-pdf':
          output = await mergePdfs(rawFiles, setProgress);
          break;
        case 'split-pdf':
          output = await splitPdf(rawFiles[0], splitOptions, setProgress);
          break;
        case 'remove-pages':
          output = await removePdfPages(rawFiles[0], selectedPages, setProgress);
          break;
        case 'extract-pages':
          output = await extractPdfPages(
            rawFiles[0],
            selectedPages,
            extractSeparate,
            setProgress
          );
          break;
        case 'pdf-to-images':
          output = await pdfToImages(rawFiles[0], pdfToImageOptions, setProgress);
          break;
        case 'pdf-to-word':
          output = await pdfToWord(rawFiles[0], setProgress);
          break;
        case 'word-to-pdf':
          output = await wordToPdf(rawFiles[0], setProgress);
          break;
        case 'excel-to-pdf':
          output = await excelToPdf(rawFiles[0], excelOptions, setProgress);
          break;
        case 'pdf-to-excel':
          output = await pdfToExcel(rawFiles[0], setProgress);
          break;
        case 'pptx-to-pdf':
          output = await pptxToPdf(rawFiles[0], setProgress);
          break;
        case 'pdf-to-pptx':
          output = await pdfToPptx(rawFiles[0], setProgress);
          break;
      }

      setResult(output);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Something went wrong while processing this file.';
      setErrorMessage(msg);
    } finally {
      setIsProcessing(false);
    }
  };

  const firstPageCount = files[0]?.pageCount ?? 0;
  const isThumbTool = activeToolId === 'remove-pages' || activeToolId === 'extract-pages';
  const canSubmit =
    files.length > 0 &&
    !isProcessing &&
    (activeToolId !== 'merge-pdf' || files.length >= 2) &&
    (!isThumbTool || selectedPages.length > 0);

  const primaryActionLabel = (() => {
    if (isProcessing) return 'Processing…';
    switch (activeToolId) {
      case 'images-to-pdf':
        return 'Convert to PDF';
      case 'merge-pdf':
        return files.length < 2 ? 'Add at least 2 PDFs' : `Merge ${files.length} PDFs`;
      case 'split-pdf':
        return 'Split PDF';
      case 'remove-pages':
        return selectedPages.length > 0
          ? `Remove ${selectedPages.length} Page${selectedPages.length === 1 ? '' : 's'}`
          : 'Select Pages to Remove';
      case 'extract-pages':
        return selectedPages.length > 0
          ? `Extract ${selectedPages.length} Page${selectedPages.length === 1 ? '' : 's'}`
          : 'Select Pages to Extract';
      case 'pdf-to-images':
        return `Convert to ${pdfToImageOptions.format.toUpperCase()}`;
      case 'pdf-to-word':
        return 'Convert to Word';
      case 'word-to-pdf':
        return 'Convert to PDF';
      case 'excel-to-pdf':
        return 'Convert to PDF';
      case 'pdf-to-excel':
        return 'Convert to Excel';
      case 'pptx-to-pdf':
        return 'Convert to PDF';
      case 'pdf-to-pptx':
        return 'Convert to PowerPoint';
    }
  })();

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-zinc-900">
        <TopBar
          onSelectCategory={handleSelectCategory}
          onQuickOpenFile={() => {
            document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
            setTimeout(() => fileInputRef.current?.click(), 180);
          }}
        />

        <main className="flex-1">
          {/* Editorial Intro Band */}
          <section className="mx-auto max-w-[1360px] px-6 pt-10 pb-8">
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"
            >
              <div className="max-w-2xl">
                <h1 className="font-display text-3xl font-bold tracking-tight text-zinc-950 sm:text-4xl text-balance">
                  Every PDF conversion, handled in seconds.
                </h1>
                <p className="mt-2.5 text-base text-zinc-600 leading-relaxed">
                  Convert JPG, PNG, WEBP, SVG, Word, Excel, and PowerPoint files, or merge, split,
                  remove, and extract PDF pages directly in your browser.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-zinc-500 shrink-0">
                <span>Runs locally in browser</span>
                <span aria-hidden="true" className="text-zinc-300">
                  ·
                </span>
                <span>No registration</span>
                <span aria-hidden="true" className="text-zinc-300">
                  ·
                </span>
                <span>Direct downloads</span>
              </div>
            </motion.div>
          </section>

          {/* Main Studio Workspace */}
          <section id="workspace" className="mx-auto max-w-[1360px] px-6 pb-16">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
              <ToolSidebar activeToolId={activeToolId} onSelectTool={handleSelectTool} />

              {/* Active Tool Canvas */}
              <div className="flex-1 min-w-0 rounded-xl border border-zinc-200 bg-white p-6 sm:p-8">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTool.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                    className="space-y-6"
                  >
                    {/* Workspace Tool Header */}
                    <div className="flex flex-col gap-3 border-b border-zinc-100 pb-5 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-zinc-200 bg-[#FAFAFA] text-rose-600">
                          <ActiveIcon className="h-5 w-5" aria-hidden="true" />
                        </div>
                        <div>
                          <h2 className="font-display text-xl font-bold tracking-tight text-zinc-950">
                            {activeTool.name}
                          </h2>
                          <p className="mt-0.5 text-sm text-zinc-500">{activeTool.description}</p>
                        </div>
                      </div>

                      <div className="text-xs font-mono text-zinc-400 shrink-0">
                        {activeTool.acceptLabel} → {activeTool.outputLabel}
                      </div>
                    </div>

                    {/* Error / Guidance Banner */}
                    <AnimatePresence>
                      {errorMessage && (
                        <motion.div
                          initial={{ opacity: 0, y: -4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          transition={{ duration: 0.15 }}
                          role="alert"
                          className="flex flex-col gap-3 rounded-xl border border-rose-200 bg-rose-50/70 p-4 text-sm text-rose-900 sm:flex-row sm:items-center sm:justify-between"
                        >
                          <div className="flex items-start gap-2.5">
                            <AlertCircle
                              className="mt-0.5 h-4 w-4 shrink-0 text-rose-600"
                              aria-hidden="true"
                            />
                            <span>{errorMessage}</span>
                          </div>
                          {suggestedToolId && (
                            <button
                              type="button"
                              onClick={() => handleSelectTool(suggestedToolId)}
                              className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 text-xs font-medium text-rose-700 border border-rose-200 hover:bg-rose-100/60 whitespace-nowrap shrink-0 cursor-pointer"
                            >
                              <span>Switch to {getToolById(suggestedToolId).name}</span>
                              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                            </button>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* DropZone (Empty or Compact Add) */}
                    {files.length === 0 ? (
                      <DropZone
                        tool={activeTool}
                        onFilesAdded={handleFilesAdded}
                        inputRef={fileInputRef}
                      />
                    ) : (
                      <div className="space-y-6">
                        {/* Hidden input for Add More */}
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept={activeTool.accept}
                          multiple={activeTool.multiple}
                          onChange={(e) => {
                            if (e.target.files?.length) {
                              handleFilesAdded(Array.from(e.target.files));
                              e.target.value = '';
                            }
                          }}
                          className="sr-only"
                        />

                        <FileQueueList
                          files={files}
                          allowReorder={
                            activeToolId === 'images-to-pdf' || activeToolId === 'merge-pdf'
                          }
                          allowMultiple={activeTool.multiple}
                          onMove={handleMoveFile}
                          onRemove={handleRemoveFile}
                          onAddMore={() => fileInputRef.current?.click()}
                        />

                        {/* Visual Page Picker for Remove / Extract */}
                        {isThumbTool && firstPageCount > 0 && !result && (
                          <PageThumbnailGrid
                            mode={activeToolId === 'remove-pages' ? 'remove' : 'extract'}
                            totalPages={firstPageCount}
                            thumbnails={thumbnails}
                            isRendering={isRenderingThumbs}
                            selectedPages={selectedPages}
                            onChangeSelected={setSelectedPages}
                          />
                        )}

                        {/* Tool-specific Settings */}
                        {!result && (
                          <ToolOptionsPanel
                            toolId={activeToolId}
                            totalPages={firstPageCount}
                            imageOptions={imageOptions}
                            onChangeImageOptions={setImageOptions}
                            splitOptions={splitOptions}
                            onChangeSplitOptions={setSplitOptions}
                            extractSeparate={extractSeparate}
                            onChangeExtractSeparate={setExtractSeparate}
                            pdfToImageOptions={pdfToImageOptions}
                            onChangePdfToImageOptions={setPdfToImageOptions}
                            excelOptions={excelOptions}
                            onChangeExcelOptions={setExcelOptions}
                          />
                        )}

                        {/* Compositor-only Progress Bar during processing */}
                        {isProcessing && (
                          <div className="space-y-2 rounded-xl border border-zinc-200 bg-[#FAFAFA] p-4">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-medium text-zinc-700">
                                Processing locally in your browser…
                              </span>
                              <span className="font-mono tabular-nums text-zinc-500">
                                {progress}%
                              </span>
                            </div>
                            <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-200">
                              <motion.div
                                className="h-full origin-left rounded-full bg-rose-600"
                                initial={{ scaleX: 0 }}
                                animate={{ scaleX: Math.max(0.05, progress / 100) }}
                                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                              />
                            </div>
                          </div>
                        )}

                        {/* Action Bar or Download Result */}
                        {result ? (
                          <ResultPanel result={result} onReset={resetWorkspaceState} />
                        ) : (
                          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-zinc-100 pt-5">
                            <button
                              type="button"
                              onClick={resetWorkspaceState}
                              disabled={isProcessing}
                              className="text-sm font-medium text-zinc-500 transition-colors hover:text-zinc-900 disabled:opacity-40 cursor-pointer"
                            >
                              Clear queue
                            </button>

                            <button
                              type="button"
                              onClick={handleProcess}
                              disabled={!canSubmit}
                              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-5 py-2.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-rose-700 active:scale-[0.98] disabled:bg-zinc-200 disabled:text-zinc-500 disabled:pointer-events-none whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600"
                            >
                              {isProcessing ? (
                                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                              ) : (
                                <ArrowRight className="h-4 w-4" aria-hidden="true" />
                              )}
                              <span>{primaryActionLabel}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </section>

          <ToolsDirectory activeToolId={activeToolId} onSelectTool={handleSelectTool} />
        </main>

        <footer className="border-t border-zinc-200 bg-white">
          <div className="mx-auto flex max-w-[1360px] flex-col gap-3 px-6 py-6 text-xs text-zinc-500 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <span className="font-display font-semibold text-zinc-900">PDFSwift</span>
              <span aria-hidden="true" className="text-zinc-300">
                ·
              </span>
              <span>Private browser-based PDF conversion and page management</span>
            </div>
            <p>All files are processed locally on your device and never uploaded to external servers.</p>
          </div>
        </footer>
      </div>
    </MotionConfig>
  );
}
